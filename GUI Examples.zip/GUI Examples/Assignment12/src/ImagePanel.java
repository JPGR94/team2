// Assignment #: 12
// Name: Tyler Wengrzyn
// StudentID: 1206094028
//  Lecture: MWF @ 10:30 
//	Description: ImagePanel class a subclass of JPanel class. It is used to define a panel where the image (happy face) is moving.
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*;
import javax.swing.*;

public class ImagePanel extends JPanel{
	private Color backColor;
	private int x, y, delay, stepX, stepY;
	private Timer timer;
	private ImageIcon ImageIcon = new ImageIcon("happyFace.gif"); 
	private final int IMAGE_DIAMETER = 20;
	public ImagePanel(int x, int y, Color backColor)
	{
		this.x = x;
		this.y = y;
		this.backColor = backColor;
		setBackground(backColor);
		setOpaque(true);
		timer = new Timer(delay, new MovingImageListener());
		timer.start();
	}
	public void up() // We want the image to start moving up, we set stepX to 0 and stepY to -3. The timer should start again using its start method.
	{
		timer.start();
		stepX = 0;
		stepY = -3;
	}
	
	public void down() // We want the image to start moving down, we set stepX to 0 and stepY to 3. The timer should start again using its start method.
	{
		timer.start();
		stepX = 0;
		stepY = 3;
	}
	
	public void left() //We want the image to start moving left, we set stepX to -3 and stepY to 0. The timer should start again using its start method.
	{
		timer.start();
		stepX = -3;
		stepY = 0;
	}
	
	public void right() //We want the image to start moving right, we set stepX to 3 and stepY to 0. The timer should start again using its start method.
	{
		timer.start();
		stepX = 3;
		stepY = 0;
	}
	
	public void suspend() //The timer should stop using its stop method.
	{
		timer.stop();
	}
	
	public void setDelay(int delayNum) //This method set the delay of the timer using its parameter.
	{
		timer.setDelay(delayNum);
	}
	
	public void paintComponent(Graphics page) //The image is painted using the paintIcon and passing the page, and the x and y coordinate for the image. (image.paintIcon(this, page, x, y))
	{
		super.paintComponent(page);
		ImageIcon.paintIcon(this, page, x, y);
	}
	
	private class MovingImageListener implements ActionListener
	{
		/*Its actionPerformed method defines how the image should move next, by changing its coordinate by adding stepX and stepY 
		 * to the corresponding variable, and re-paint the ImagePanel after such change. In case the image hits the side of the panel, 
		 * it needs to reverse its direction. The width of the panel can be obtained by "getSize().getWidth()". For instance, you can check 
		 * if the image hit the right hand side panel by: if (x > getSize().getWidth()-IMAGE_DIAMETER && stepY == 0)*/
		public void actionPerformed(ActionEvent event)
		{
			//figure out how to delete image, repaint image, and loop directions while moving (delete, repaint)
				x = x + stepX;
				y = y + stepY;
				if (x > getSize().getWidth()-IMAGE_DIAMETER && stepY == 0) //wrong variable for size?
				{
					left();
				}
				else if (x < 0 && stepY == 0) //not sure if this is correct for opposite side
				{
					right();
				}
				else if (y > getSize().getHeight()-IMAGE_DIAMETER && stepX == 0)
				{
					up();
				}
				else if (y < 0 && stepX == 0)
				{
					down();
				}
				repaint();
		}
	}

}
