// Assignment #: 12
// Name: Tyler Wengrzyn
// StudentID: 1206094028
//  Lecture: MWF @ 10:30 
//  Description: ControlPanel class extends JPanel and contains 5 buttons and
// 		 1 slider that control the change in movement of the image. Also
//		 contains two subclasses that implement Listener interfaces,
//		 which are then used on the buttons and slider.

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

public class ControlPanel extends JPanel {

	//Declare instance variables

	private ImagePanel face;
	private int width, height;
	private JButton up, down, left, right, stop;
	private JSlider delay;
	private JPanel side1, side2;

	// Constructor
	// Creates all of the components (JButtons, JSlider, and ImagePanel) and adds Listeners
	// to them, and adds the components to the panel. Sets the size of the panel.

  	public ControlPanel(int width, int height)
  	{
       	this.width = width;
       	this.height = height;
       	setSize(width, height);
       	setLayout(new GridLayout(1,2));
       	// create an ImagePanel
       	face = new ImagePanel(0,0,Color.red);
        // create panels with appropriate layouts
       	side1 = new JPanel();
       	side2 = new JPanel();
       	side1.setLayout(new GridLayout(5,1));
       	side2.setLayout(new GridLayout(2,1));
		// create your buttons
       	up = new JButton("Up");
       	down = new JButton("Down");
       	left = new JButton("Left");
       	right = new JButton("Right");
       	stop = new JButton("Stop");
     
        // add Listener to your buttons
       	up.addActionListener(new ButtonListener());
       	down.addActionListener(new ButtonListener());
       	left.addActionListener(new ButtonListener());
       	right.addActionListener(new ButtonListener());
       	stop.addActionListener(new ButtonListener());

		// create slider use new JSlider(SwingConstants.VERTICAL, 0, 50, 20);
       	delay = new JSlider(SwingConstants.VERTICAL, 0, 50, 20);
		// add ChangeListner to the slider
       	delay.addChangeListener(new SliderListener());
		// use the method setPaintLabels(true)
       	delay.setPaintLabels(true);
		// use the setLabelTable(slider.createStandardLabels(10));
       	delay.setLabelTable(delay.createStandardLabels(10));



		// add panels to the main panel
       	side1.add(up);
       	side1.add(down);
       	side1.add(left);
       	side1.add(right);
       	side1.add(stop);
       	side2.add(side1);
       	side2.add(delay);
       	add(side2);
       	add(face);


    }

  	private class ButtonListener implements ActionListener {

		// actionPerformed
		// Must be defined from the ActionListener class. Takes the button that
		// has been pressed and changes the motion of the image accordingly.

		public void actionPerformed(ActionEvent event)
		{

            Object action = event.getSource();
            // decide which button is clicked
            if (event.getSource() == up)
            {
            	face.up();
            }
            else if (event.getSource() == down)
            {
            	face.down();
            }
            else if (event.getSource() == left)
            {
            	face.left();
            }
            else if (event.getSource() == right)
            {
            	face.right();
            }
            else if (event.getSource() == stop)
            {
            	face.suspend();
            }
         }

     	} //end of ButtonListener

   	private class SliderListener implements ChangeListener
   	{

		// stateChanged
		// Must be defined from the ChangeListener class. Takes the value of the
		// slider and sets the delay of the image Timer to that value.

        	public void stateChanged(ChangeEvent event)
        	{
        		face.setDelay(delay.getValue());
            }

     	} //end of SliderListener

} //end of ControlPanel