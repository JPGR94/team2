// Assignment #: 6
//         Name: Tyler Wengrzyn
//    StudentID: 1206094028
//      Lecture: MWF 10:30
//  Description: Makes a panel for stored computers, displayed under Store Inventory tab


import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;
import javax.swing.*;

import java.util.*;

public class StorePanel extends JPanel
 {
   private ArrayList compList;
   private PurchasePanel purchasePanel;
   private JLabel brandLabel, priceLabel, memoryLabel, typeLabel, speedLabel, confirmationLabel;
   private JTextField brand, price, memory, type, speed;
   private JTextArea output;
   private double priceNum;
   private int memoryNum, speedNum;

 public StorePanel(ArrayList compList, PurchasePanel pPanel)
  {
    this.compList = compList;
    this.purchasePanel = pPanel;

    // orgranize components here
    // here is an example
    JPanel left = new JPanel();
    left.setLayout(new GridLayout(3,1));
    JPanel leftTop = new JPanel();
    leftTop.setLayout(new GridLayout(5,1));
    JPanel leftBottom = new JPanel();
    JPanel panel1 = new JPanel();
    panel1.setLayout(new GridLayout(5,2));
    confirmationLabel = new JLabel();
    confirmationLabel.setForeground(Color.RED);
    leftTop.add(confirmationLabel);
    brandLabel = new JLabel ("Brand Name");
    brand = new JTextField ();
    priceLabel = new JLabel ("Price");
    price = new JTextField ();
    memoryLabel = new JLabel ("Memory");
    memory = new JTextField ();
    typeLabel = new JLabel ("CPU Type");
    type = new JTextField ();
    speedLabel = new JLabel ("CPU Speed");
    speed = new JTextField ();
    //left middle panel
    panel1.add(brandLabel);
    panel1.add(brand);
    panel1.add(priceLabel);
    panel1.add(price);
    panel1.add(memoryLabel);
    panel1.add(memory);
    panel1.add(typeLabel);
    panel1.add(type);
    panel1.add(speedLabel);
    panel1.add(speed);
    JButton button1 = new JButton("Store");
    button1.addActionListener(new ButtonListener());
    leftBottom.add(button1);
    JPanel panel2= new JPanel();
    panel2.setLayout(new GridLayout(1,1));
    output = new JTextArea ("No Computer", 20, 70);
    output.setEditable(false);
    panel2.add(output);
    left.add(leftTop);
    left.add(panel1);
    left.add(leftBottom);
    setLayout(new GridLayout(1,2));
    add(left);
    add(panel2);
  }



  private class ButtonListener implements ActionListener
   {
	public void actionPerformed(ActionEvent event)
	 {
		 // if there is no error, add a computer to computer list
		 // otherwise, show an error message
		try
		{
		if (!brand.getText().equals("") && !price.getText().equals("") && !memory.getText().equals("") && !speed.getText().equals("") && !type.getText().equals(""))
		{
				confirmationLabel.setText("Computer added.");
				Computer newComp = new Computer();
				newComp.setBrandName(brand.getText());
				priceNum = Double.parseDouble(price.getText()); 
				newComp.setPrice(priceNum);
				memoryNum = Integer.parseInt(memory.getText());
		        newComp.setMemory(memoryNum);
		        speedNum = Integer.parseInt(speed.getText());
		        newComp.setCPU(type.getText(), speedNum);
				purchasePanel.addComputer(newComp);
				output.setText("");
				for (int i = 0; i < compList.size(); i++)
				{
					String s = output.getText();
					String print = s + compList.get(i);
					output.setText(print);
				}
			}
			else 
			{
				confirmationLabel.setText("Please enter all fields.");
			}
		}
		catch(NumberFormatException e)
		{
			confirmationLabel.setText("Please enter a numeric value in Price, Memory, and/or Speed.");
		}
		}
		}
		}