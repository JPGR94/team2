// Assignment #: 6
//         Name: Tyler Wengrzyn
//    StudentID: 1206094028
//      Lecture: MWF 10:30
//  Description: Makes a panel for purchases, displayed under Customer Purchase tab

import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

import javax.swing.*;

import java.util.*;

public class PurchasePanel extends JPanel
 {
   private ArrayList <Computer> compList;
   private JLabel totalLabel;
   private JTextArea totalPrice;
   private double totalNum;
   private ArrayList<JCheckBox> boxList = new ArrayList<JCheckBox>();
   private JPanel left = new JPanel();

   public PurchasePanel(ArrayList compList)
    {
	  this.compList = compList;
	  NumberFormat nf = NumberFormat.getCurrencyInstance();
	  totalNum = 0.00;
	  totalLabel = new JLabel ("Current Total Purchase");
	  totalPrice = new JTextArea ("\t\t\t" + nf.format(totalNum), 20, 70);
	  totalPrice.setEditable(false);
	  //JPanel left = new JPanel();
	  left.setLayout(new GridLayout(compList.size(),1));
	  JPanel right = new JPanel();
	  right.setLayout(new GridLayout(2,1));
	  JPanel rightTop = new JPanel();
	  JPanel rightBottom = new JPanel();
	  rightBottom.setVisible(true);
	  rightTop.add(totalLabel);
	  rightBottom.add(totalPrice);
	  right.add(rightTop);
	  right.add(rightBottom);
	  //left.add(box);
	  setLayout(new GridLayout(1,2));
	  add(left);
	  add(right);
	  // orgranize components for purchase panel

    }
   
	public void addComputer(Computer newComp)
	{
		compList.add(newComp);
		JCheckBox box = new JCheckBox(newComp.toString());
		box.addItemListener(new CheckBoxListener());
		left.add(box);
		boxList.add(box);
	}


 private class CheckBoxListener implements ItemListener
  {
	   public void itemStateChanged(ItemEvent event)
	    {
			// compute the total purchase amount when a check box is
			// checked or unchecked.
		   for(int i = 0; i < boxList.size(); i++)
		   {
		   if (boxList.get(i).isSelected())
		   {
			   NumberFormat nf = NumberFormat.getCurrencyInstance();
			   totalNum = totalNum + compList.get(i).getPrice();
			   totalPrice.setText("\t\t\t" + nf.format(totalNum));
		   }
		   else if (!boxList.get(i).isSelected())
		   {
			   NumberFormat nf = NumberFormat.getCurrencyInstance();
			   totalNum = totalNum - compList.get(i).getPrice();
			   totalPrice.setText("\t\t\t" + nf.format(totalNum));
		   }
		   }
		}
  }


}