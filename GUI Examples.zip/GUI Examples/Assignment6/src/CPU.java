// Assignment #: 6
//         Name: Tyler Wengrzyn
//    StudentID: 1206094028
//      Lecture: MWF 10:30
//  Description: Creates an object CPU

public class CPU 
{
	private int speed;
    private String type;
    
    public CPU()   
    {
        speed = 0;
        type = "?";
    }
    
	public String getType()
	{
		return type;
	}
	
	public int getSpeed()
	{
		return speed;
	}
	
	public void setType(String newType)
	{
		type = newType;
	}
	
	public void setSpeed(int newSpeed)
	{
		speed = newSpeed;
	}
	
	public String toString()
	{
		String words = type + "," + speed + "HZ";
		return words; 
	}
}
