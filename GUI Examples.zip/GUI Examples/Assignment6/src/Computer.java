// Assignment #: 6
//         Name: Tyler Wengrzyn
//    StudentID: 1206094028
//      Lecture: MWF 10:30
//  Description: Creates an object Computer

import java.text.NumberFormat;
public class Computer 
{
	private int memory;
    private String brandName;
    private CPU cpu;
    private double price;
    
    public Computer( )   
    {
        memory = 0;
        brandName = "?";
        price = 0.0;
        cpu = new CPU();
    }
    
	  public String getBrandName()
	  {
		  return brandName;
	  }
	  
	  public CPU getCPU()
	  {
		  return cpu;
	  }
	  
	  public int getMemory()
	  {
		  return memory;
	  }
	  
	  public double getPrice()
	  {
		  return price;
	  }
	  
	  public void setBrandName(String BrandName)
	  {
		  brandName = BrandName;
	  }
	  
	  public void setCPU(String cpuType, int cpuSpeed)
	  {
		  cpu.setType(cpuType);
		  cpu.setSpeed(cpuSpeed);
	  }
	  
	  public void setMemory(int memoryAmount)
	  {
		  memory = memoryAmount;
	  }
	  
	  public void setPrice(double newPrice)
	  {
		  price = newPrice;
	  }
	  
	  public String toString()
	  {
		  NumberFormat nf = NumberFormat.getCurrencyInstance();
		  String phrase = "\nBrandName:\t" + brandName +
				  "\nCPU:\t\t" + cpu.toString() +
				  "\nMemory:\t\t" + memory + "M" +
				  "\nPrice:\t\t" + nf.format(price) + "\n\n";
		  return phrase;
	  }

}