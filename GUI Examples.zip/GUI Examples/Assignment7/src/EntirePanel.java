// Assignment #: 7
//         Name: Tyler Wengrzyn
//    StudentID: 1206094028
//      Lecture: MWF 10:30
//  Description: The entire panel creates components of this applet. It also has a definition for
// the CanvasPanel,  and listener classes.

import java.awt.*;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.event.*;
import java.util.ArrayList;

public class EntirePanel extends JPanel
{

   private DrawingPanel drawing;
   private JButton undo;
   private ArrayList<Letter> charList = new ArrayList();
   private JRadioButton[] colorRButtons;
   private Color color;
   private int fontSize;
   private String[] fonts;
   private JComboBox fontSizeSelector;
   private JPanel layout1, layout2;
   private Letter letter;
   //add instance variables as needed

   //The constructor initializes components and arrange them.
   public EntirePanel()
   { //fill out the code here
	   fonts = new String[] {"24", "28", "32", "34", "36"};
	   fontSizeSelector = new JComboBox(fonts);
	   fontSizeSelector.addActionListener(new FontListener());
	   fontSize = 24;
	   color = Color.black;
	   colorRButtons = new JRadioButton[5];
	   colorRButtons[0] = new JRadioButton ("black", true);
	   colorRButtons[1] = new JRadioButton("red");
	   colorRButtons[2] = new JRadioButton("blue");
	   colorRButtons[3] = new JRadioButton("green");
	   colorRButtons[4] = new JRadioButton("orange");
	   ButtonGroup group = new ButtonGroup();
	   group.add(colorRButtons[0]);
	   group.add(colorRButtons[1]);
	   group.add(colorRButtons[2]);
	   group.add(colorRButtons[3]);
	   group.add(colorRButtons[4]);
	   ColorListener colors = new ColorListener();
	   colorRButtons[0].addActionListener(colors);
	   colorRButtons[1].addActionListener(colors);
	   colorRButtons[2].addActionListener(colors);
	   colorRButtons[3].addActionListener(colors);
	   colorRButtons[4].addActionListener(colors);
	   undo = new JButton("Undo");
	   undo.addActionListener(new ButtonListener());
	   drawing = new DrawingPanel();
	   setLayout(new GridLayout(2,1));
	   layout1 = new JPanel();
	   layout2 = new JPanel();
	   layout1.setLayout(new GridLayout(1,7));
	   layout2.setLayout(new GridLayout(1,1));
	   layout1.add(undo);
	   layout1.add(fontSizeSelector);
	   layout1.add(colorRButtons[0]);
	   layout1.add(colorRButtons[1]);
	   layout1.add(colorRButtons[2]);
	   layout1.add(colorRButtons[3]);
	   layout1.add(colorRButtons[4]);
	   layout2.add(drawing);
	   add(layout1);
	   add(layout2);
   }

   //accessor method of drawing panel
   public DrawingPanel getDrawingPanel()
   {
      return drawing;
   }

   // listener class for "undo" button.
   private class ButtonListener implements ActionListener
   {
      public void actionPerformed (ActionEvent event)
      {
       		 Object source = event.getSource();

      		 if (source == undo)  //in case "undo" button is pushed
      		 {
      		     //fill out the code here
      		      if (charList.size() - 1 >= 0)
      		      {
      		    	charList.remove(charList.size() - 1);
      		      }
      		    drawing.repaint();
              }

      }
   } // end of ButtonListener


    // listener class to set the color chosen by a user using
    // the radio buttons.
    private class ColorListener implements ActionListener
     {
        public void actionPerformed(ActionEvent event)
         {    //fill out the code
	        	if (colorRButtons[0].isSelected())
	        	{
	        		color = Color.black;
	        	}
	        	else if (colorRButtons[1].isSelected())
	        	{
	        		color = Color.red;
	        	}
	        	else if (colorRButtons[2].isSelected())
	        	{
	        		color = Color.blue;
	        	}
	        	else if (colorRButtons[3].isSelected())
	        	{
	        		color = Color.green;        	
	        	} 
	        	else if (colorRButtons[4].isSelected())
	        	{
	        		color = Color.orange;
	        	} 
        	
         }
    }

 	private class FontListener implements ActionListener
 	{
 	     public void actionPerformed(ActionEvent event)
 	      {
 	          //fill out the code here
 	    	 if (fontSizeSelector.getSelectedIndex() == 0)
 	    	 {
 	    		fontSize = 24;
 	    	 }
 	    	 else if (fontSizeSelector.getSelectedIndex() == 1)
 	    	 {
 	    		fontSize = 28;
 	    	 }
 	    	else if (fontSizeSelector.getSelectedIndex() == 2)
	    	 {
 	    		fontSize = 32;
	    	 }
 	    	else if (fontSizeSelector.getSelectedIndex() == 3)
	    	 {
 	    		fontSize = 34;
	    	 }
 	    	else if (fontSizeSelector.getSelectedIndex() == 4)
	    	 {
 	    		fontSize = 36;
	    	 }
 	      }
 	 } //end of FontListener

 	 class DrawingPanel extends JPanel
 	//DrawingPanel is the panel where pressed keys will be drawn  private class DrawingPanel extends JPanel
 	 {
 	    private Point currentPoint;
 	    private char keyChar = 'A'; // Default key

 	    //constructor to request focus to listen to keys, set background to white,
 	    //make the panel listen to keys and a mouse
 	    public DrawingPanel()
 	    {
 	        requestFocus();
        	setBackground(Color.white);
        	this.addKeyListener(new LetterListener());
        	this.addMouseListener(new PointListener());
      	}

     	//this method draws all characters pressed by a user so far
     	public void paintComponent(Graphics page)
     	{
       		super.paintComponent(page);
       		//fill out the code
       		for (int i = 0; i < charList.size(); i++)
       		{
       			charList.get(i).draw(page);
       		}
      	}

     	/** This method is overriden to enable keyboard focus */
     	public boolean isFocusable()
     	{
     	    return true;
     	}

   		// listener class to listen to keyboard keys
   		private class LetterListener implements KeyListener
   		{
   		   public void keyReleased(KeyEvent e) {}
   		   public void keyTyped(KeyEvent e) {}

   		   // in case that a key is pressed, the following will be executed.
   		   public void keyPressed(KeyEvent e)
   		   {
        		 //e.getKeyChar()return the character

        		 // fill out the code
   			   	letter = new Letter(currentPoint.x, currentPoint.y, e.getKeyChar(), color, fontSize);
   			   	charList.add(letter);
        		drawing.repaint();
       		}
    	} // end of LetterListener


   		// listener class that listens to the mouse
   		public class PointListener implements MouseListener
   		{
   			  //in case that a user presses using a mouse,
   			  //record the point where it was pressed.
   			  public void mousePressed (MouseEvent event)
   			  {
   			     currentPoint = event.getPoint();
   			     requestFocus();
   			  }

     		public void mouseClicked (MouseEvent event) {}
     		public void mouseReleased (MouseEvent event) {}
     		public void mouseEntered (MouseEvent event) {}
     		public void mouseExited (MouseEvent event) {}
     		public void mouseMoved(MouseEvent event) {}
     		public void mouseDragged(MouseEvent event) {}

    	}// end of PointListener

  	} // end of DrawingPanel Class

} // end of EntirePanel Class