// Assignment #: 7
//         Name: Tyler Wengrzyn
//    StudentID: 1206094028
//      Lecture: MWF 10:30
//  Description: The Letter class creates a letter to draw
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
public class Letter {
	
	private int x;
	private int y;
	private char ch;
	private Color color;
	private int fontSize;
	private String textString;
	String facename = "TimesRoman";
	int style = Font.PLAIN;
	
	
	public Letter(int x, int y, char ch, Color color, int fontSize)
	{
		this.x = x;
		this.y = y;
		this.ch = ch;
		this.color = color;
		this.fontSize = fontSize;
	}
	
	public void draw(Graphics page)
	{
		textString = Character.toString(ch);
		page.setColor(color);
		page.setFont(new Font(facename, style, fontSize)); 
		page.drawString(textString, x, y);
	}

}
