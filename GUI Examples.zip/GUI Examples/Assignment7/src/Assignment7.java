// Assignment #: 7
//         Name: Tyler Wengrzyn
//    StudentID: 1206094028
//      Lecture: 2
//      Time spent:
//  Description: Assignment 7 combines the panel containing  a button, a slider, and radio buttons, and the drawing panel
//  using a JSplitPane.

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;

public class Assignment7 extends JApplet
{
 	public void init()
 	 {
 	   // create an EntirePanel object and add it to the applet
 	   EntirePanel ePanel = new EntirePanel();

 	   JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, ePanel, ePanel.getDrawingPanel());

 	   getContentPane().add(sp);

    //set applet size to 500 X 300
 	   setSize (500, 300);
 	 }

}