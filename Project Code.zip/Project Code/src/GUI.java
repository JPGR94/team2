/**
 * @author Tyler Wengrzyn
 * 
 * @version 4/11/2016
 * 
 * Provides GUI assets for dice game*/

import java.awt.Color;
import java.util.Random;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.imageio.ImageIO;
import java.awt.RenderingHints;
import java.awt.Font;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JApplet
{

	private JButton vsComp, vsPlayer, stats, quit, start, roll, replay, menu;
	private JPanel layout, buttonSizer, buttonLayout, titleLayout, titleImage, 
					player1Layout, player2Layout, diceRoll, die1, die2, die3;
	private Random random;
	private ImageIcon imageIcon;
	private JRadioButton diceOption1, diceOption2, diceOption3;
	private JLabel title, names, player1Stats, player2Stats , player1Logo, player2Logo;
	private JFrame mainFrame;
	/**This is basically to provide commands for the buttons*/
	ActionListener actionListener = new ActionListener() 
	{
        public void actionPerformed(ActionEvent actionEvent) 
        {
          if(actionEvent.getActionCommand() == "vsComp")
          {
        	  player2Logo = new JLabel("<html>Computer </html>", JLabel.LEFT); //Separate with <br>
        	  player2Logo.setFont(new Font("TimesRoman", Font.PLAIN, 54));
        	  player2Logo.setForeground(Color.black);
        	  player2Layout = new JPanel();
        	  player2Layout.setBackground(Color.gray);
        	  mainFrame.getContentPane().removeAll();
        	  ruleScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "vsPlayer")
          {
        	  player2Logo = new JLabel("<html>Player 2 </html>", JLabel.LEFT); //Separate with <br>
        	  player2Logo.setFont(new Font("TimesRoman", Font.PLAIN, 54));
        	  player2Logo.setForeground(Color.black);
        	  player2Layout = new JPanel();
        	  player2Layout.setBackground(Color.blue);
        	  mainFrame.getContentPane().removeAll();
        	  ruleScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "stats")
          {
        	  mainFrame.getContentPane().removeAll();
        	  statScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "quit")
          {
        	  System.exit(0);
          }
          else if(actionEvent.getActionCommand() == "menu")
          {
        	  mainFrame.getContentPane().removeAll();
        	  titleScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "start")
          {
        	  die1 = new JPanel();
        	  die1.setBackground(Color.orange);
        	  die2 = new JPanel();
        	  die2.setBackground(Color.orange);
        	  die3 = new JPanel();
        	  die3.setBackground(Color.orange);
        	  die1.add(die(1));
        	  die2.add(die(2));
        	  die3.add(die(3));
        	  mainFrame.getContentPane().removeAll();
        	  gameScreen();
        	  ((JPanel)mainFrame.getContentPane()).revalidate();
              mainFrame.repaint();
          }
          else if(actionEvent.getActionCommand() == "roll")
          {
        	  
          }
        }
	};
	/**Intended as die object, just need to figure out graphics
	 * @param dieValue is supposed to be the value rolled on the die
	 * @param dieFace is to supply the image of the die face
	 * @param dieSpot is to provide placement for the dice*/
	public JLabel die(int dieValue)
	{
		if(dieValue == 1)
		{
			ImageIcon dieFace = new ImageIcon("DieFace1.jpg");
			JLabel label = new JLabel(dieFace);
			return label;
		}
		else if(dieValue == 2)
		{
			ImageIcon dieFace = new ImageIcon("DieFace2.jpg");
			JLabel label = new JLabel(dieFace);
			return label;
		}
		else if(dieValue == 3)
		{
			ImageIcon dieFace = new ImageIcon("DieFace3.jpg");
			JLabel label = new JLabel(dieFace);
			return label;
		}
		else if(dieValue == 4)
		{
			ImageIcon dieFace = new ImageIcon("DieFace4.jpg");
			JLabel label = new JLabel(dieFace);
			return label;
		}
		else if(dieValue == 5)
		{
			ImageIcon dieFace = new ImageIcon("DieFace5.jpg");
	       	JLabel label = new JLabel(dieFace);
	       	return label;
		}
		else if(dieValue == 6)
		{
			ImageIcon dieFace = new ImageIcon("DieFace6.jpg");
	       	JLabel label = new JLabel(dieFace);
	       	return label;
		}
		return null;
	}
	/**Provides display for title screen*/
	public void titleScreen()
	{
       	layout = new JPanel();
       	layout.setBackground(Color.red);
       	layout.setLayout(new GridLayout(3,1));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.red);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.red);
       	buttonLayout.setLayout(new GridLayout(4, 1, 25, 25));
       	
       	vsComp = new JButton("VS. Comp");
       	vsComp.setPreferredSize(new Dimension(100, 35));
       	vsPlayer = new JButton("VS. Player");
       	vsPlayer.setPreferredSize(new Dimension(100, 35));
       	stats = new JButton("Stats");
       	stats.setPreferredSize(new Dimension(100, 35));
       	quit = new JButton("Quit");
       	quit.setPreferredSize(new Dimension(100, 35));
       	
       	vsComp.setActionCommand("vsComp");
        vsComp.addActionListener(actionListener);
        vsPlayer.setActionCommand("vsPlayer");
        vsPlayer.addActionListener(actionListener);
        stats.setActionCommand("stats");
        stats.addActionListener(actionListener);
        quit.setActionCommand("quit");
        quit.addActionListener(actionListener);
       	
       	buttonLayout.add(vsComp);
       	buttonLayout.add(vsPlayer);
       	buttonLayout.add(stats);
       	buttonLayout.add(quit);
       	
       	buttonSizer.add(buttonLayout);
       	
       	title = new JLabel("Working DIEtle", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 64));
       	title.setForeground(Color.black);
       	
       	names = new JLabel("Created by: Adam Charney, Francisco Goncalves de Almeida Filh, Caio Pinheiro de Carvalho, Tyler Wengrzyn, and Jacob Wiens", JLabel.CENTER);
       	names.setFont(new Font("TimesRoman", Font.PLAIN, 24));
       	names.setForeground(Color.black);
       	
       	titleLayout = new JPanel();
       	titleLayout.setLayout(new GridLayout(2, 1));
       	titleLayout.setBackground(Color.red);
       	titleLayout.add(title);
       	titleLayout.add(names);
       	
       	imageIcon = new ImageIcon("DiceGraphic.jpg");
       	JLabel label = new JLabel(imageIcon);

       	titleImage = new JPanel();
       	titleImage.add(label);
       	titleImage.setBackground(Color.red);
       	
       	layout.add(titleLayout);
       	layout.add(titleImage);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Provides display for rule screen*/
	public void ruleScreen()
	{
		layout = new JPanel();
       	layout.setBackground(Color.yellow);
       	layout.setLayout(new GridLayout(3,1));
       	
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.yellow);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.yellow);
       	buttonLayout.setLayout(new GridLayout(1, 3, 15, 15));
       	
       	start = new JButton("Start");
       	start.setActionCommand("start");
        start.addActionListener(actionListener);
        start.setPreferredSize(new Dimension(80, 40));
       	
       	menu = new JButton("Menu");
    	menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        menu.setPreferredSize(new Dimension(80, 40));
       	
        buttonLayout.add(menu);
       	buttonLayout.add(start);
       	
       	buttonSizer.add(buttonLayout);
       	
       	title = new JLabel("Rules", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.black);
       	
       	names = new JLabel("<html>* On the top of the screen, there will be a target score to reach."
       			+ "<br>* Each player will attempt to reach this score by rolling dice."
       			+ "<br>* You may choose to use either 1, 2, or 3 6-sided dice."
       			+ "<br>* If you choose to roll the 3 dice, then you will have to use a single die for your next 3 turns."
       			+ "<br>* If the total number you roll is greater than the amount needed to reach the target score, then it will not count."
       			+ "<br>* Each player will take turns rolling the dice by clicking the Roll button at the bottom of the screen."
       			+ "<br>* First player to reach the target score wins. </html>", JLabel.LEFT); //Separate with <br>
       	names.setFont(new Font("TimesRoman", Font.PLAIN, 24));
       	names.setForeground(Color.black);
       	
       	layout.add(title);
       	layout.add(names);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Provides display for game screen*/
	public void gameScreen()
	{
       	layout = new JPanel();
       	layout.setBackground(Color.orange);
       	layout.setLayout(new GridLayout(4,1));
       	
       	diceRoll = new JPanel();
       	diceRoll.setBackground(Color.orange);
       	diceRoll.setLayout(new GridLayout(1, 3));
       	diceRoll.add(die1);
       	diceRoll.add(die2);
       	diceRoll.add(die3);
       	
       	title = new JLabel("Player 1's Turn", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.red);
       	
       	/*title = new JLabel("Player 2's Turn", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.blue);*/
       	
       	/*title = new JLabel("Computer's Turn", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.gray);*/
       	
       	menu = new JButton("Menu");
       	menu.setPreferredSize(new Dimension(80, 40));
    	menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        
        roll = new JButton("Roll");
    	roll.setActionCommand("roll");
        roll.addActionListener(actionListener);
        
        buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.orange);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.orange);
       	buttonLayout.setLayout(new GridLayout(4, 1, 0, 5));
       	buttonLayout.add(menu);
       	
       	buttonSizer.add(buttonLayout);
       	
       	JPanel midLayout = new JPanel();
       	midLayout.setBackground(Color.orange);
       	midLayout.setLayout(new GridLayout(1,1));
       	
       	JPanel diceOptions = new JPanel();
       	diceOptions.setBackground(Color.orange);
       	diceOptions.setLayout(new GridLayout(3,1));
       	
       	diceOption1 = new JRadioButton("1 Die");
       	diceOption1.setBackground(Color.orange);
       	diceOption1.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	diceOption1.setForeground(Color.black);
       	diceOption1.setHorizontalAlignment(AbstractButton.CENTER);
       	
       	diceOption2 = new JRadioButton("2 Dice");
       	diceOption2.setBackground(Color.orange);
       	diceOption2.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	diceOption2.setForeground(Color.black);
       	diceOption2.setHorizontalAlignment(AbstractButton.CENTER);
       	
       	diceOption3 = new JRadioButton("3 Dice");
       	diceOption3.setBackground(Color.orange);
       	diceOption3.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	diceOption3.setForeground(Color.black);
       	diceOption3.setHorizontalAlignment(AbstractButton.CENTER);
       	
       	ButtonGroup group = new ButtonGroup();
       	group.add(diceOption1);
       	diceOption1.setSelected(true);
       	group.add(diceOption2);
       	group.add(diceOption3);
       	
       	diceOptions.add(diceOption1);
       	diceOptions.add(diceOption2);
       	diceOptions.add(diceOption3);
       	
       	player1Logo = new JLabel("<html>Player 1 </html>", JLabel.LEFT); //Separate with <br>
       	player1Logo.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	player1Logo.setForeground(Color.black);
       	
       	player1Stats = new JLabel("<html>*Current Score: "
       			+ "<br>*Points Needed: </html>", JLabel.LEFT); //Separate with <br>
       	player1Stats.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	player1Stats.setForeground(Color.black);
       	
       	player2Stats = new JLabel("<html>*Current Score: "
       			+ "<br>*Points Needed: </html>", JLabel.LEFT); //Separate with <br>
       	player2Stats.setFont(new Font("TimesRoman", Font.PLAIN, 34));
       	player2Stats.setForeground(Color.black);
       	
       	player1Layout = new JPanel();
       	player1Layout.setBackground(Color.red);
       	player1Layout.setLayout(new GridLayout(2,1));
       	player1Layout.add(player1Logo);
       	player1Layout.add(player1Stats);
       	
       	player2Layout.setLayout(new GridLayout(2,1));
       	player2Layout.add(player2Logo);
       	player2Layout.add(player2Stats);
       	
       	midLayout.add(player1Layout);
       	midLayout.add(diceOptions);
       	midLayout.add(player2Layout);
       	
        
        layout.add(title);
        layout.add(diceRoll);
        layout.add(midLayout);
        layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Provides display for stat screen*/
	public void statScreen()
	{
       	layout = new JPanel();
       	layout.setBackground(Color.blue);
       	layout.setLayout(new GridLayout(3,1));
       	
       	title = new JLabel("Stats", JLabel.CENTER);
       	title.setFont(new Font("TimesRoman", Font.PLAIN, 54));
       	title.setForeground(Color.black);
       	
       	menu = new JButton("Menu");
    	menu.setActionCommand("menu");
        menu.addActionListener(actionListener);
        
       	buttonSizer = new JPanel();
       	buttonSizer.setBackground(Color.blue);
       	buttonLayout = new JPanel();
       	buttonLayout.setBackground(Color.blue);
       	buttonLayout.setLayout(new GridLayout(1, 3, 0, 5));
       	buttonLayout.add(menu);
       	buttonSizer.add(buttonLayout);
       	
       	layout.add(title);
       	layout.add(buttonSizer);
       	
       	mainFrame.add(layout);
	}
	/**Provides display for win screen*/
	public void winScreen()
	{
       	layout = new JPanel();
       	layout.setBackground(Color.green);
       	layout.setLayout(new GridLayout(2, 1));
       	add(layout);
	}
	/**Provides display for player select screen*/
	public void playerSelect()
	{
       	layout = new JPanel();
       	layout.setBackground(Color.black);
       	layout.setLayout(new GridLayout(1,2));
       	add(layout);
	}
	
	public void init()
	{
		mainFrame = new JFrame();
       	mainFrame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
		titleScreen();
		mainFrame.setVisible(true);
	}

}
